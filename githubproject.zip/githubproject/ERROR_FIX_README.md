# 故宫博物院小程序 - 错误修复说明

## 已修复的问题

### 问题描述
错误日志显示：
```
app.json: ["tabBar"]["list"][0]["iconPath"]: "assets/images/home.png" 未找到
```

### 解决方案
已修改 `app.json`，暂时移除了底部导航栏的图标配置，保留文字标签功能。

## 如何添加图标

### 所需图标文件
需要在 `miniprogram/assets/images/` 目录下添加以下 10 个图标文件（尺寸建议：81px × 81px）：

| 文件名 | 说明 |
|--------|------|
| `home.png` | 首页 - 未选中状态 |
| `home-active.png` | 首页 - 选中状态 |
| `ticket.png` | 门票 - 未选中状态 |
| `ticket-active.png` | 门票 - 选中状态 |
| `guide.png` | 导览 - 未选中状态 |
| `guide-active.png` | 导览 - 选中状态 |
| `shop.png` | 文创 - 未选中状态 |
| `shop-active.png` | 文创 - 选中状态 |
| `user.png` | 我的 - 未选中状态 |
| `user-active.png` | 我的 - 选中状态 |

### 添加图标后配置
添加图标文件后，修改 `app.json` 的 tabBar 配置，为每个 tab 添加 `iconPath` 和 `selectedIconPath`：

```json
{
  "pagePath": "pages/index/index",
  "text": "首页",
  "iconPath": "assets/images/home.png",
  "selectedIconPath": "assets/images/home-active.png"
}
```

## 当前状态
✅ 小程序现在可以正常编译和运行  
✅ 底部导航栏正常显示（纯文字）  
✅ 所有页面功能正常可用

## 下一步建议
1. 准备好图标文件
2. 放置到 `assets/images/` 目录
3. 更新 `app.json` 配置
4. 重新编译预览
