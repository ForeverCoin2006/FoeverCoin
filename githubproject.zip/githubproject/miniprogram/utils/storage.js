const TOKEN_KEY = 'token'
const USER_INFO_KEY = 'userInfo'
const CART_KEY = 'cart'

const setToken = (token) => {
  wx.setStorageSync(TOKEN_KEY, token)
}

const getToken = () => {
  return wx.getStorageSync(TOKEN_KEY)
}

const removeToken = () => {
  wx.removeStorageSync(TOKEN_KEY)
}

const setUserInfo = (userInfo) => {
  wx.setStorageSync(USER_INFO_KEY, userInfo)
}

const getUserInfo = () => {
  return wx.getStorageSync(USER_INFO_KEY)
}

const removeUserInfo = () => {
  wx.removeStorageSync(USER_INFO_KEY)
}

const getCart = () => {
  return wx.getStorageSync(CART_KEY) || []
}

const addToCart = (product) => {
  const cart = getCart()
  const existIndex = cart.findIndex(item => item.id === product.id)
  
  if (existIndex > -1) {
    cart[existIndex].quantity += 1
  } else {
    cart.push({ ...product, quantity: 1 })
  }
  
  wx.setStorageSync(CART_KEY, cart)
  return cart
}

const removeFromCart = (productId) => {
  let cart = getCart()
  cart = cart.filter(item => item.id !== productId)
  wx.setStorageSync(CART_KEY, cart)
  return cart
}

const updateCartQuantity = (productId, quantity) => {
  const cart = getCart()
  const item = cart.find(item => item.id === productId)
  if (item) {
    item.quantity = quantity
    wx.setStorageSync(CART_KEY, cart)
  }
  return cart
}

const clearCart = () => {
  wx.removeStorageSync(CART_KEY)
  return []
}

const getCartCount = () => {
  const cart = getCart()
  return cart.reduce((total, item) => total + item.quantity, 0)
}

module.exports = {
  setToken,
  getToken,
  removeToken,
  setUserInfo,
  getUserInfo,
  removeUserInfo,
  getCart,
  addToCart,
  removeFromCart,
  updateCartQuantity,
  clearCart,
  getCartCount
}
