Page({
  data: {
    currentLocation: '太和门',
    scenicSpots: [
      { id: 1, name: '太和殿', distance: '200m', audio: true, ar: true, image: '/assets/images/spot1.png' },
      { id: 2, name: '中和殿', distance: '350m', audio: true, ar: true, image: '/assets/images/spot2.png' },
      { id: 3, name: '保和殿', distance: '500m', audio: true, ar: false, image: '/assets/images/spot3.png' },
      { id: 4, name: '乾清宫', distance: '800m', audio: true, ar: true, image: '/assets/images/spot4.png' },
      { id: 5, name: '坤宁宫', distance: '1km', audio: true, ar: false, image: '/assets/images/spot5.png' },
      { id: 6, name: '御花园', distance: '1.2km', audio: true, ar: true, image: '/assets/images/spot6.png' }
    ],
    recommendedRoutes: [
      { id: 1, name: '经典精华路线', duration: '2小时', spots: 8, desc: '太和殿→中和殿→保和殿→乾清宫' },
      { id: 2, name: '深度游览路线', duration: '4小时', spots: 15, desc: '覆盖主要宫殿和展览馆' },
      { id: 3, name: '亲子互动路线', duration: '3小时', spots: 10, desc: '适合带小朋友的家庭游客' }
    ],
    aiAssistant: {
      isOnline: true,
      lastQuestion: ''
    },
    isAudioPlaying: false,
    currentAudioSpot: null
  },

  onLoad() {
    this.getCurrentLocation()
  },

  getCurrentLocation() {
    wx.showLoading({ title: '定位中...' })
    setTimeout(() => {
      wx.hideLoading()
    }, 1000)
  },

  onSpotTap(e) {
    const { id } = e.currentTarget.dataset
    const spot = this.data.scenicSpots.find(s => s.id === id)
    wx.navigateTo({
      url: `/pages/guide/detail?id=${id}&name=${spot.name}`
    })
  },

  onAudioPlay(e) {
    const { id } = e.currentTarget.dataset
    const spot = this.data.scenicSpots.find(s => s.id === id)
    
    if (this.data.currentAudioSpot === id && this.data.isAudioPlaying) {
      this.setData({ isAudioPlaying: false, currentAudioSpot: null })
      wx.showToast({ title: '已暂停播放', icon: 'none' })
    } else {
      this.setData({ isAudioPlaying: true, currentAudioSpot: id })
      wx.showToast({ title: `正在播放: ${spot.name}讲解`, icon: 'none' })
    }
  },

  onARTap(e) {
    const { id } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/ar/index?spotId=${id}`
    })
  },

  onRouteTap(e) {
    const { id } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/guide/route?id=${id}`
    })
  },

  onOpenMap() {
    wx.navigateTo({
      url: '/pages/map/index'
    })
  },

  onAIChat() {
    wx.navigateTo({
      url: '/pages/ai/chat'
    })
  },

  onScanQRCode() {
    wx.scanCode({
      success: (res) => {
        console.log('扫码结果:', res)
        wx.showToast({ title: '识别成功', icon: 'success' })
      }
    })
  }
})
