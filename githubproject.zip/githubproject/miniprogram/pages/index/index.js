Page({
  data: {
    bannerList: [
      { id: 1, image: '/assets/images/banner1.png', title: '紫禁城建成600年特展' },
      { id: 2, image: '/assets/images/banner2.png', title: '故宫文创新品发布' },
      { id: 3, image: '/assets/images/banner3.png', title: '数字故宫沉浸体验' }
    ],
    quickEntries: [
      { id: 1, icon: 'ticket', name: '购票预约', url: '/pages/ticket/ticket' },
      { id: 2, icon: 'guide', name: '智能导览', url: '/pages/guide/guide' },
      { id: 3, icon: 'map', name: '故宫地图', url: '/pages/map/map' },
      { id: 4, icon: 'ai', name: 'AI助手', url: '/pages/ai/ai' },
      { id: 5, icon: 'ar', name: 'AR互动', url: '/pages/ar/ar' },
      { id: 6, icon: 'shop', name: '文创商城', url: '/pages/shop/shop' },
      { id: 7, icon: 'aigc', name: '文创定制', url: '/pages/custom/custom' },
      { id: 8, icon: 'more', name: '更多服务', url: '/pages/more/more' }
    ],
    hotExhibitions: [
      { id: 1, title: '千里江山图特展', image: '/assets/images/exhibition1.png', date: '2024.01-2024.06' },
      { id: 2, title: '宫廷瓷器精品展', image: '/assets/images/exhibition2.png', date: '常设展览' },
      { id: 3, title: '钟表馆珍品展', image: '/assets/images/exhibition3.png', date: '常设展览' }
    ],
    newsList: [
      { id: 1, title: '故宫博物院2024年春节开放公告', date: '2024-01-15' },
      { id: 2, title: '数字故宫APP全新升级上线', date: '2024-01-10' },
      { id: 3, title: '故宫文创入驻全国各大机场', date: '2024-01-05' }
    ]
  },

  onLoad() {
    this.loadData()
  },

  onPullDownRefresh() {
    this.loadData().then(() => {
      wx.stopPullDownRefresh()
    })
  },

  loadData() {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve()
      }, 500)
    })
  },

  onBannerTap(e) {
    const { id } = e.currentTarget.dataset
    console.log('Banner clicked:', id)
  },

  onQuickEntryTap(e) {
    const { url } = e.currentTarget.dataset
    if (url) {
      wx.navigateTo({ url })
    }
  },

  onExhibitionTap(e) {
    const { id } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/exhibition/detail?id=${id}`
    })
  },

  onNewsTap(e) {
    const { id } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/news/detail?id=${id}`
    })
  },

  onTicketTap() {
    wx.switchTab({
      url: '/pages/ticket/ticket'
    })
  },

  onGuideTap() {
    wx.switchTab({
      url: '/pages/guide/guide'
    })
  }
})
