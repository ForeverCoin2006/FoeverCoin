const app = getApp()

Page({
  data: {
    isLoggedIn: false,
    userInfo: null,
    orderStats: [
      { id: 'pending', name: '待使用', count: 2 },
      { id: 'used', name: '已使用', count: 5 },
      { id: 'refund', name: '退款', count: 0 }
    ],
    menuItems: [
      { id: 'orders', icon: '📋', name: '我的订单', url: '/pages/user/orders' },
      { id: 'tickets', icon: '🎫', name: '我的门票', url: '/pages/user/tickets' },
      { id: 'favorites', icon: '❤️', name: '我的收藏', url: '/pages/user/favorites' },
      { id: 'history', icon: '📜', name: '浏览历史', url: '/pages/user/history' },
      { id: 'address', icon: '📍', name: '收货地址', url: '/pages/user/address' },
      { id: 'coupon', icon: '🎁', name: '优惠券', url: '/pages/user/coupon' },
      { id: 'feedback', icon: '💬', name: '意见反馈', url: '/pages/user/feedback' },
      { id: 'about', icon: 'ℹ️', name: '关于我们', url: '/pages/user/about' }
    ],
    vipInfo: {
      level: '黄金会员',
      points: 2580,
      nextLevel: 5000,
      benefits: ['门票9折', '文创9折', '专属客服']
    }
  },

  onLoad() {
    this.checkLoginStatus()
  },

  onShow() {
    this.checkLoginStatus()
  },

  checkLoginStatus() {
    const userInfo = app.globalData.userInfo
    const isLoggedIn = app.globalData.isLoggedIn
    this.setData({ userInfo, isLoggedIn })
  },

  onLogin() {
    wx.getUserProfile({
      desc: '用于完善用户资料',
      success: (res) => {
        app.globalData.userInfo = res.userInfo
        app.globalData.isLoggedIn = true
        wx.setStorageSync('userInfo', res.userInfo)
        this.setData({
          userInfo: res.userInfo,
          isLoggedIn: true
        })
        wx.showToast({ title: '登录成功', icon: 'success' })
      },
      fail: () => {
        wx.showToast({ title: '登录取消', icon: 'none' })
      }
    })
  },

  onLogout() {
    wx.showModal({
      title: '提示',
      content: '确定要退出登录吗？',
      success: (res) => {
        if (res.confirm) {
          app.logout()
          this.setData({
            userInfo: null,
            isLoggedIn: false
          })
          wx.showToast({ title: '已退出', icon: 'success' })
        }
      }
    })
  },

  onOrderStatTap(e) {
    const { id } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/user/orders?type=${id}`
    })
  },

  onMenuTap(e) {
    const { url } = e.currentTarget.dataset
    wx.navigateTo({ url })
  },

  onVipTap() {
    wx.navigateTo({
      url: '/pages/user/vip'
    })
  },

  onAvatarTap() {
    if (this.data.isLoggedIn) {
      wx.showActionSheet({
        itemList: ['查看资料', '退出登录'],
        success: (res) => {
          if (res.tapIndex === 0) {
            wx.navigateTo({ url: '/pages/user/profile' })
          } else if (res.tapIndex === 1) {
            this.onLogout()
          }
        }
      })
    }
  },

  onContactTap() {
    wx.makePhoneCall({
      phoneNumber: '400-XXX-XXXX'
    })
  }
})
