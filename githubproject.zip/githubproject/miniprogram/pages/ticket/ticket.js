Page({
  data: {
    ticketTypes: [
      { id: 1, name: '成人票', price: 60, desc: '适用于18岁以上成人' },
      { id: 2, name: '学生票', price: 20, desc: '凭有效学生证使用' },
      { id: 3, name: '老年票', price: 0, desc: '60岁以上老人免费' },
      { id: 4, name: '儿童票', price: 0, desc: '6岁以下儿童免费' }
    ],
    selectedDate: '',
    selectedTicket: null,
    quantity: 1,
    timeSlots: [
      { id: 1, time: '08:30-12:00', available: 5000 },
      { id: 2, time: '12:00-16:00', available: 3000 },
      { id: 3, time: '14:00-17:00', available: 2000 }
    ],
    selectedTimeSlot: null,
    minDate: '',
    maxDate: ''
  },

  onLoad() {
    this.initDatePicker()
  },

  initDatePicker() {
    const today = new Date()
    const maxDate = new Date()
    maxDate.setDate(maxDate.getDate() + 7)

    this.setData({
      selectedDate: this.formatDate(today),
      minDate: this.formatDate(today),
      maxDate: this.formatDate(maxDate)
    })
  },

  formatDate(date) {
    const year = date.getFullYear()
    const month = String(date.getMonth() + 1).padStart(2, '0')
    const day = String(date.getDate()).padStart(2, '0')
    return `${year}-${month}-${day}`
  },

  onDateChange(e) {
    this.setData({
      selectedDate: e.detail.value
    })
  },

  onTicketSelect(e) {
    const { id } = e.currentTarget.dataset
    const ticket = this.data.ticketTypes.find(t => t.id === id)
    this.setData({
      selectedTicket: ticket
    })
  },

  onTimeSlotSelect(e) {
    const { id } = e.currentTarget.dataset
    const timeSlot = this.data.timeSlots.find(t => t.id === id)
    this.setData({
      selectedTimeSlot: timeSlot
    })
  },

  onQuantityChange(e) {
    const { action } = e.currentTarget.dataset
    let quantity = this.data.quantity
    if (action === 'minus' && quantity > 1) {
      quantity--
    } else if (action === 'plus' && quantity < 10) {
      quantity++
    }
    this.setData({ quantity })
  },

  onSubmit() {
    const { selectedTicket, selectedDate, selectedTimeSlot, quantity } = this.data

    if (!selectedTicket) {
      wx.showToast({ title: '请选择票种', icon: 'none' })
      return
    }
    if (!selectedTimeSlot) {
      wx.showToast({ title: '请选择时段', icon: 'none' })
      return
    }

    const totalPrice = selectedTicket.price * quantity

    wx.showModal({
      title: '确认订单',
      content: `票种：${selectedTicket.name}\n日期：${selectedDate}\n时段：${selectedTimeSlot.time}\n数量：${quantity}张\n总价：¥${totalPrice}`,
      success: (res) => {
        if (res.confirm) {
          this.createOrder()
        }
      }
    })
  },

  createOrder() {
    wx.showLoading({ title: '提交中...' })
    setTimeout(() => {
      wx.hideLoading()
      wx.showToast({ title: '预约成功', icon: 'success' })
    }, 1000)
  }
})
