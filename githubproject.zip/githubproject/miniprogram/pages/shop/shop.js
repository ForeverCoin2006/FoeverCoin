Page({
  data: {
    categories: [
      { id: 0, name: '全部' },
      { id: 1, name: '文具' },
      { id: 2, name: '饰品' },
      { id: 3, name: '家居' },
      { id: 4, name: '服饰' },
      { id: 5, name: '定制' }
    ],
    currentCategory: 0,
    bannerList: [
      { id: 1, title: '故宫口红系列', desc: '宫廷色号，典雅之选' },
      { id: 2, title: '文创定制专区', desc: 'AIGC专属定制' }
    ],
    hotProducts: [
      { id: 1, name: '故宫口红·郎窑红', price: 199, originalPrice: 299, sales: 2580, image: '' },
      { id: 2, name: '千里江山图笔记本', price: 68, originalPrice: 88, sales: 1890, image: '' },
      { id: 3, name: '宫廷瑞兽手办套装', price: 299, originalPrice: 399, sales: 956, image: '' },
      { id: 4, name: '故宫日历2024', price: 98, originalPrice: 128, sales: 3200, image: '' }
    ],
    products: [
      { id: 1, name: '故宫文创书签套装', price: 58, sales: 1200, image: '', category: 1 },
      { id: 2, name: '宫廷风格耳环', price: 128, sales: 890, image: '', category: 2 },
      { id: 3, name: '紫禁城香薰蜡烛', price: 168, sales: 650, image: '', category: 3 },
      { id: 4, name: '故宫联名T恤', price: 158, sales: 2100, image: '', category: 4 },
      { id: 5, name: '御笔朱批钢笔', price: 298, sales: 430, image: '', category: 1 },
      { id: 6, name: '宫廷发簪', price: 88, sales: 780, image: '', category: 2 }
    ],
    cartCount: 0
  },

  onLoad() {
    this.loadData()
  },

  onPullDownRefresh() {
    this.loadData().then(() => {
      wx.stopPullDownRefresh()
    })
  },

  loadData() {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve()
      }, 500)
    })
  },

  onCategoryChange(e) {
    const { id } = e.currentTarget.dataset
    this.setData({ currentCategory: id })
  },

  onBannerTap(e) {
    const { id } = e.currentTarget.dataset
    console.log('Banner:', id)
  },

  onProductTap(e) {
    const { id } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/shop/detail?id=${id}`
    })
  },

  onAddToCart(e) {
    const { id } = e.currentTarget.dataset
    const cartCount = this.data.cartCount + 1
    this.setData({ cartCount })
    wx.showToast({ title: '已加入购物车', icon: 'success' })
  },

  onAIGCCustom() {
    wx.navigateTo({
      url: '/pages/custom/index'
    })
  },

  onCartTap() {
    wx.navigateTo({
      url: '/pages/shop/cart'
    })
  },

  onSearchTap() {
    wx.navigateTo({
      url: '/pages/shop/search'
    })
  }
})
